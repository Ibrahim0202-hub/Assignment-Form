const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;


app.use(cors());
app.use(express.json());


app.post("/submit", (req, res) => {
  const { name, email, message } = req.body;


  if (!name || !email || !message) {
    return res.json({
      success: false,
      message: "All fields are required"
    });
  }

  console.log("Form Data Received:", req.body);

 
  res.json({
    success: true,
    message: "Form submitted successfully"
  });
});


app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
