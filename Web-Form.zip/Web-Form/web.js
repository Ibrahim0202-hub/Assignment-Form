
const form = document.getElementById("contactForm");
const responseMessage = document.getElementById("responseMessage");


form.addEventListener("submit", function (event) {


  event.preventDefault();

  
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const message = document.getElementById("message").value;

 
  fetch("http://localhost:3000/submit", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      name: name,
      email: email,
      message: message
    })
  })
  .then(response => response.json())
  .then(data => {
  
    responseMessage.innerText = data.message;
  })
  .catch(error => {
    responseMessage.innerText = "Error submitting form";
  });

});
